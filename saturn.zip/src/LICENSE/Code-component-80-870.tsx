MIT License

Copyright (c) 2025 Saturn Wallet

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

DISCLAIMER:

This software is provided for educational and experimental purposes. Users should:

1. Always test with small amounts first
2. Backup recovery phrases securely
3. Understand the risks of cryptocurrency transactions
4. Use at their own risk

The developers are not responsible for:
- Loss of funds due to user error
- Security vulnerabilities in dependencies
- Blockchain network issues
- Market price fluctuations
- Any other losses or damages

By using this software, you agree to these terms and acknowledge that 
cryptocurrency transactions are irreversible and you are solely responsible 
for the security of your private keys and recovery phrases.
