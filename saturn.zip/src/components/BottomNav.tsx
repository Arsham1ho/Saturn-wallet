import { Home, ArrowLeftRight, Activity, Settings, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../utils/i18n/LanguageContext';
import { toast } from 'sonner@2.0.3';

interface BottomNavProps {
  currentPage: string;
  onNavigate: (page: 'home' | 'swap' | 'activity' | 'settings' | 'chat') => void;
}

export function BottomNav({ currentPage, onNavigate }: BottomNavProps) {
  const { t } = useLanguage();
  
  const navItems = [
    { id: 'chat', icon: MessageCircle, label: t.nav.chat, comingSoon: true },
    { id: 'swap', icon: ArrowLeftRight, label: t.nav.swap },
    { id: 'home', icon: Home, label: t.nav.home },
    { id: 'activity', icon: Activity, label: t.nav.activity },
    { id: 'settings', icon: Settings, label: t.nav.settings },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-xl border-t border-slate-900/50 max-w-[430px] mx-auto">
      <div className="flex items-center justify-between px-2 py-3 w-full">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <motion.button
              key={item.id}
              onClick={() => {
                if (item.comingSoon) {
                  toast.info('Coming Soon! 🚀', { duration: 2000 });
                } else {
                  onNavigate(item.id as any);
                }
              }}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all flex-1 relative ${
                isActive 
                  ? 'text-purple-500' 
                  : 'text-slate-500 hover:text-slate-300'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                animate={{
                  y: isActive ? -2 : 0,
                }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Icon className={`w-6 h-6 ${isActive ? 'stroke-[2.5]' : ''}`} />
              </motion.div>
              <span className={`text-xs font-semibold ${isActive ? 'opacity-100' : 'opacity-80'}`}>
                {item.label}
              </span>
              {item.comingSoon && (
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-purple-500 rounded-full" />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}