import { useState, useEffect, useRef } from 'react';
import { Send, Lock, ChevronLeft, Users, MessageCircle, Shield, Reply, X, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { useLanguage } from '../../utils/i18n/LanguageContext';
import { TokenLogo } from '../TokenLogo';
import { PlanetAvatar } from '../PlanetAvatar';
import { AnimalAvatar } from '../AnimalAvatar';
import { UserProfileCard } from '../UserProfileCard';

interface Reaction {
  [emoji: string]: string[]; // emoji -> array of walletIds
}

interface Message {
  id: string;
  walletId: string;
  username: string;
  message: string;
  timestamp: string;
  reactions?: Reaction;
  replyTo?: string | null;
}

interface TokenChat {
  symbol: string;
  name: string;
  logo?: string;
  logoUrl?: string;
  color?: string;
  amount: number;
}

interface ChatProps {
  walletId: string;
  tokens: TokenChat[];
}

const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '🔥', '👏'];

// Retry utility with exponential backoff
async function retryFetch<T>(
  fn: () => Promise<Response>,
  maxRetries: number = 3,
  initialDelay: number = 500
): Promise<Response> {
  let lastError: any;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fn();
      
      // If response is ok or it's a non-retryable error (4xx), return it
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }
      
      // Server error (5xx), retry
      lastError = new Error(`Server error: ${response.status}`);
    } catch (error: any) {
      lastError = error;
      
      // Check if we should retry (network errors, timeouts)
      const shouldRetry = i < maxRetries - 1;
      
      if (!shouldRetry) {
        throw error;
      }
      
      // Exponential backoff
      const delay = initialDelay * Math.pow(2, i);
      console.log(`[Chat] Retry attempt ${i + 1}/${maxRetries}, waiting ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  throw lastError;
}

export function Chat({ walletId, tokens }: ChatProps) {
  const { t } = useLanguage();
  const [selectedToken, setSelectedToken] = useState<TokenChat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [username, setUsername] = useState<string>('');
  const [currentUserProfilePicture, setCurrentUserProfilePicture] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [memberCount, setMemberCount] = useState(0);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [showReactions, setShowReactions] = useState<string | null>(null);
  const [longPressTimer, setLongPressTimer] = useState<NodeJS.Timeout | null>(null);
  const [touchStart, setTouchStart] = useState<{ x: number; y: number; time: number; messageId: string } | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [pullStartY, setPullStartY] = useState(0);
  const [pullDistance, setPullDistance] = useState(0);
  const [selectedUserProfile, setSelectedUserProfile] = useState<{ walletId: string; username: string } | null>(null);
  
  // Profile pictures cache for chat users
  const [userProfiles, setUserProfiles] = useState<Record<string, { username: string; profilePicture: string | null }>>({});

  // Get username and profile picture for current user
  useEffect(() => {
    const fetchUsername = async () => {
      try {
        // In client-side architecture, profile data is in localStorage
        const storedUsername = localStorage.getItem('saturn_username') || '@Anonymous';
        const storedProfilePicture = localStorage.getItem('saturn_profile_picture') || null;
        
        setUsername(storedUsername);
        setCurrentUserProfilePicture(storedProfilePicture);
        
        console.log('[Chat] ✅ User profile loaded from localStorage');
      } catch (error) {
        console.error('[Chat] Error fetching username:', error);
        setUsername('@Anonymous');
      }
    };
    
    fetchUsername();

    // Listen for profile picture updates
    const handleProfileUpdate = () => {
      console.log('[Chat] Profile picture updated, refreshing...');
      fetchUsername();
    };

    window.addEventListener('profilePictureUpdated', handleProfileUpdate);
    return () => window.removeEventListener('profilePictureUpdated', handleProfileUpdate);
  }, [walletId]);

  // Fetch messages when token is selected
  useEffect(() => {
    if (selectedToken) {
      fetchMessages();
      // Poll for new messages every 3 seconds
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedToken]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle keyboard showing on mobile
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const handleResize = () => {
        if (document.activeElement === inputRef.current) {
          setTimeout(() => {
            inputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }, 100);
        }
      };
      
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }
  }, []);

  const fetchMessages = async (silent = true) => {
    if (!selectedToken) return;
    
    try {
      if (!silent) setLoading(true);
      
      const response = await retryFetch(() => 
        fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-e5bc10d1/chat/${selectedToken.symbol}/messages`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        )
      );

      if (response.ok) {
        const data = await response.json();
        const fetchedMessages = data.messages || [];
        setMessages(fetchedMessages);
        setMemberCount(data.memberCount || 0);
        
        // Fetch profile pictures for unique users in messages
        await fetchUserProfiles(fetchedMessages);
      } else {
        if (!silent) {
          toast.error(`Failed to load messages`);
        }
      }
    } catch (error) {
      console.error('[Chat] Error fetching messages:', error);
      if (!silent) {
        toast.error('Failed to connect to chat server');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const fetchUserProfiles = async (messages: Message[]) => {
    // Get unique wallet IDs from messages (excluding already cached and current user)
    const uniqueWalletIds = Array.from(new Set(
      messages
        .map(msg => msg.walletId)
        .filter(id => id !== walletId && !userProfiles[id])
    ));

    if (uniqueWalletIds.length === 0) return;

    // Fetch profile info for each unique user
    const profilePromises = uniqueWalletIds.map(async (userId) => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-e5bc10d1/wallet-info/${userId}`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        );
        
        if (response.ok) {
          const data = await response.json();
          return {
            walletId: userId,
            username: data.username || '@Anonymous',
            profilePicture: data.profilePicture || null,
          };
        }
      } catch (error) {
        console.error(`[Chat] Error fetching profile for ${userId}:`, error);
      }
      return null;
    });

    const profiles = await Promise.all(profilePromises);
    
    // Update userProfiles state with fetched data
    const newProfiles: Record<string, { username: string; profilePicture: string | null }> = {};
    profiles.forEach(profile => {
      if (profile) {
        newProfiles[profile.walletId] = {
          username: profile.username,
          profilePicture: profile.profilePicture,
        };
      }
    });

    setUserProfiles(prev => ({ ...prev, ...newProfiles }));
  };

  const canSendMessage = () => {
    if (!selectedToken) return false;
    return selectedToken.amount > 0;
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedToken || !canSendMessage()) return;

    const messageText = newMessage.trim();
    const replyToId = replyingTo?.id || null;

    // Optimistic UI - add message immediately
    const optimisticMessage: Message = {
      id: `temp-${Date.now()}`,
      walletId,
      username,
      message: messageText,
      timestamp: new Date().toISOString(),
      replyTo: replyToId,
    };

    setMessages(prev => [...prev, optimisticMessage]);
    setNewMessage('');
    setReplyingTo(null);

    // Haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(10);
    }

    try {
      setSending(true);
      const response = await retryFetch(() =>
        fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-e5bc10d1/chat/${selectedToken.symbol}/send`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              walletId,
              username,
              message: messageText,
              replyTo: replyToId,
            }),
          }
        )
      );

      if (response.ok) {
        // Remove optimistic message and fetch real messages
        await fetchMessages(false);
      } else {
        // Remove optimistic message on error
        setMessages(prev => prev.filter(m => m.id !== optimisticMessage.id));
        const error = await response.json();
        toast.error(error.error || 'Failed to send message');
      }
    } catch (error) {
      // Remove optimistic message on error
      setMessages(prev => prev.filter(m => m.id !== optimisticMessage.id));
      console.error('[Chat] Error sending message:', error);
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleReaction = async (messageId: string, emoji: string) => {
    if (!selectedToken || !canSendMessage()) {
      toast.error('You need to own this token to react');
      return;
    }

    // Optimistic UI
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const reactions = { ...(msg.reactions || {}) };
        if (reactions[emoji]) {
          if (reactions[emoji].includes(walletId)) {
            // Remove reaction
            reactions[emoji] = reactions[emoji].filter(id => id !== walletId);
            if (reactions[emoji].length === 0) {
              delete reactions[emoji];
            }
          } else {
            // Add reaction
            reactions[emoji] = [...reactions[emoji], walletId];
          }
        } else {
          reactions[emoji] = [walletId];
        }
        return { ...msg, reactions };
      }
      return msg;
    }));

    setShowReactions(null);

    // Haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(10);
    }

    try {
      const response = await retryFetch(() =>
        fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-e5bc10d1/chat/${selectedToken.symbol}/react`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              walletId,
              messageId,
              emoji,
            }),
          }
        )
      );

      if (response.ok) {
        // Refresh to get accurate state
        await fetchMessages();
      } else {
        // Revert optimistic update
        await fetchMessages();
        const error = await response.json();
        toast.error(error.error || 'Failed to add reaction');
      }
    } catch (error) {
      // Revert optimistic update
      await fetchMessages();
      console.error('[Chat] Error adding reaction:', error);
      toast.error('Failed to add reaction');
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getReplyMessage = (replyToId: string | null | undefined) => {
    if (!replyToId) return null;
    return messages.find(msg => msg.id === replyToId);
  };

  // Pull to refresh handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (messagesContainerRef.current?.scrollTop === 0) {
      setPullStartY(e.touches[0].clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (pullStartY > 0 && messagesContainerRef.current?.scrollTop === 0) {
      const distance = Math.max(0, e.touches[0].clientY - pullStartY);
      setPullDistance(Math.min(distance, 100));
    }
  };

  const handleTouchEnd = () => {
    if (pullDistance > 60) {
      setRefreshing(true);
      fetchMessages(false);
    }
    setPullStartY(0);
    setPullDistance(0);
  };

  // Long press handlers
  const handleMessageTouchStart = (e: React.TouchEvent, messageId: string) => {
    if (!canSendMessage()) return;
    
    const touch = e.touches[0];
    setTouchStart({
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
      messageId
    });

    const timer = setTimeout(() => {
      setShowReactions(messageId);
      if ('vibrate' in navigator) {
        navigator.vibrate([10, 20, 10]);
      }
    }, 500);
    setLongPressTimer(timer);
  };

  const handleMessageTouchMove = (e: React.TouchEvent) => {
    if (!touchStart || !longPressTimer) return;

    const touch = e.touches[0];
    const deltaX = Math.abs(touch.clientX - touchStart.x);
    const deltaY = Math.abs(touch.clientY - touchStart.y);

    // Cancel long press if moved too much
    if (deltaX > 10 || deltaY > 10) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
      setTouchStart(null);
    }
  };

  const handleMessageTouchEnd = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
    setTouchStart(null);
  };

  // Token selection view
  if (!selectedToken) {
    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="px-4 py-6 space-y-6">
          {/* Header */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-purple-600 to-purple-500 rounded-2xl">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl">{t.chat.chat}</h1>
                <p className="text-slate-400 text-sm">{t.chat.selectToken}</p>
              </div>
            </div>

          </div>

          {/* Token List */}
          <div className="space-y-3">
            {tokens.filter(token => token.amount > 0).length > 0 && (
              <>
                <div className="text-xs text-slate-500 uppercase tracking-wider px-2">
                  Your Token Communities
                </div>
                {tokens.filter(token => token.amount > 0).map((token, index) => (
                  <motion.button
                    key={token.symbol}
                    onClick={() => setSelectedToken(token)}
                    className="w-full p-4 bg-gradient-to-br from-slate-900/80 to-slate-800/80 rounded-2xl border border-slate-700/50 hover:border-purple-500/50 transition-all active:scale-[0.98]"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <div className="flex items-center gap-3.5 relative overflow-hidden">
                      {/* High quality background image */}
                      <div 
                        className="absolute inset-0 opacity-5"
                        style={{
                          backgroundImage: `url('https://images.unsplash.com/photo-1673526759317-be71a1243e3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdyYWRpZW50JTIwcHVycGxlfGVufDF8fHx8MTc2MjE5NTc4OHww&ixlib=rb-4.1.0&q=80&w=1080')`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center'
                        }}
                      />
                      
                      <div className="relative">
                        <TokenLogo token={token} size="md" />
                        <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-slate-900">
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse m-0.5" />
                        </div>
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-white text-sm truncate">{token.name}</span>
                          <span className="text-slate-400 text-xs">${token.symbol}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs">
                          <div className="flex items-center gap-1 text-purple-400">
                            <Shield className="w-3 h-3" />
                            <span>Holder</span>
                          </div>
                          <span className="text-slate-600">•</span>
                          <span className="text-slate-500 truncate">
                            {token.amount.toFixed(2)} {token.symbol}
                          </span>
                        </div>
                      </div>
                      <MessageCircle className="w-4.5 h-4.5 text-purple-400 flex-shrink-0" />
                    </div>
                  </motion.button>
                ))}
              </>
            )}

            {tokens.filter(token => token.amount === 0).length > 0 && (
              <>
                <div className="pt-4 pb-2 text-xs text-slate-500 uppercase tracking-wider px-2">
                  Locked Communities
                </div>
                {tokens.filter(token => token.amount === 0).map((token, index) => (
                  <motion.div
                    key={token.symbol}
                    className="w-full p-4 bg-slate-900/30 rounded-2xl border border-slate-800/50 relative overflow-hidden"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: (tokens.filter(t => t.amount > 0).length + index) * 0.05 }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-red-500/5 to-transparent" />
                    <div className="flex items-center gap-3.5 relative">
                      <div className="relative opacity-50">
                        <TokenLogo token={token} size="md" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Lock className="w-5 h-5 text-red-400" />
                        </div>
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-slate-400 text-sm truncate">{token.name}</span>
                          <span className="text-slate-500 text-xs">${token.symbol}</span>
                        </div>
                        <p className="text-red-400 text-xs flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          <span className="truncate">{t.chat.mustOwnToken}</span>
                        </p>
                      </div>
                      <div className="px-3 py-1 bg-red-500/10 text-red-400 rounded-lg text-xs border border-red-500/20 flex-shrink-0">
                        Locked
                      </div>
                    </div>
                  </motion.div>
                ))}
              </>
            )}
          </div>
        </div>

        {/* User Profile Card */}
        <AnimatePresence>
          {selectedUserProfile && (
            <UserProfileCard
              walletId={selectedUserProfile.walletId}
              username={selectedUserProfile.username}
              onClose={() => setSelectedUserProfile(null)}
              isOwnProfile={selectedUserProfile.walletId === walletId}
            />
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Chat view
  return (
    <div className="min-h-screen bg-black text-white pb-20 flex flex-col">
      {/* Backdrop for closing reaction picker */}
      {showReactions && (
        <div
          className="fixed inset-0 z-40"
          style={{ backgroundColor: 'transparent' }}
          onClick={() => setShowReactions(null)}
          onTouchEnd={() => setShowReactions(null)}
        />
      )}

      {/* Header */}
      <div className="relative px-4 py-3 border-b border-slate-800/50 bg-gradient-to-br from-slate-900/95 to-black/95 backdrop-blur-xl sticky top-0 z-30">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 to-transparent" />
        <div className="flex items-center gap-3 relative">
          <motion.button
            onClick={() => {
              setSelectedToken(null);
              setReplyingTo(null);
              setShowReactions(null);
            }}
            className="p-2 hover:bg-slate-800/50 rounded-xl transition-colors active:scale-95"
            whileTap={{ scale: 0.9 }}
          >
            <ChevronLeft className="w-5 h-5" />
          </motion.button>
          
          <div className="relative">
            <TokenLogo token={selectedToken} size="md" />
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-slate-900">
              <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse m-0.5" />
            </div>
          </div>
          
          <button
            onClick={() => setSelectedUserProfile({ walletId, username })}
            className="flex-1 hover:opacity-80 transition-opacity text-left"
          >
            <h2 className="text-white">{selectedToken.name}</h2>
            <p className="text-slate-400 text-xs flex items-center gap-1">
              <Users className="w-3 h-3" />
              {memberCount} {t.chat.membersOnline}
            </p>
          </button>

          {/* User avatar in header */}
          <button
            onClick={() => setSelectedUserProfile({ walletId, username })}
            className="hover:opacity-80 transition-opacity"
          >
            <div className="relative">
              <AnimalAvatar size="sm" walletId={walletId} profilePicture={currentUserProfilePicture} />
              <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-slate-900">
                <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse m-0.5" />
              </div>
            </div>
          </button>

          {!canSendMessage() && (
            <motion.div 
              className="flex items-center gap-1 px-3 py-1.5 bg-red-500/10 text-red-400 rounded-xl text-xs border border-red-500/20"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <Lock className="w-3 h-3" />
              Locked
            </motion.div>
          )}
        </div>
      </div>

      {/* Pull to refresh indicator */}
      {pullDistance > 0 && (
        <div 
          className="flex justify-center py-2 bg-slate-900/50"
          style={{ 
            transform: `translateY(${Math.min(pullDistance - 60, 0)}px)`,
            opacity: pullDistance / 60 
          }}
        >
          <RefreshCw 
            className={`w-5 h-5 text-purple-400 ${pullDistance > 60 ? 'animate-spin' : ''}`}
            style={{ transform: `rotate(${pullDistance * 3}deg)` }}
          />
        </div>
      )}

      {/* Messages */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto px-4 py-4 space-y-3"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ 
          overscrollBehavior: 'contain',
          WebkitOverflowScrolling: 'touch'
        }}
      >
        {loading && messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <MessageCircle className="w-12 h-12 text-purple-500 mx-auto" />
              </motion.div>
              <p className="text-slate-500">{t.chat.loading}</p>
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-4">
              <div className="relative">
                <TokenLogo token={selectedToken} size="xl" />
                <motion.div
                  className="absolute -bottom-2 -right-2 w-10 h-10 bg-gradient-to-br from-purple-600 to-purple-500 rounded-2xl flex items-center justify-center"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <MessageCircle className="w-5 h-5" />
                </motion.div>
              </div>
              <div>
                <h3 className="text-white mb-1">Welcome to {selectedToken.name}</h3>
                <p className="text-slate-500 text-sm">{t.chat.noMessages}</p>
                <p className="text-slate-600 text-xs mt-1">Be the first to say something!</p>
              </div>
            </div>
          </div>
        ) : (
          <AnimatePresence>
            {messages.map((msg, index) => {
              const isOwnMessage = msg.walletId === walletId;
              const replyMsg = getReplyMessage(msg.replyTo);
              const hasReactions = msg.reactions && Object.keys(msg.reactions).length > 0;
              const isOptimistic = msg.id.startsWith('temp-');
              
              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: isOptimistic ? 0.6 : 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.2 }}
                  className={`flex gap-2 items-start ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  {/* Avatar */}
                  <button
                    onClick={() => setSelectedUserProfile({ walletId: msg.walletId, username: msg.username })}
                    className="flex-shrink-0 pt-1 cursor-pointer hover:opacity-80 transition-opacity active:scale-95"
                  >
                    <AnimalAvatar 
                      size="sm" 
                      walletId={msg.walletId} 
                      profilePicture={
                        msg.walletId === walletId 
                          ? currentUserProfilePicture 
                          : userProfiles[msg.walletId]?.profilePicture || null
                      } 
                    />
                  </button>

                  <div className={`flex-1 min-w-0 max-w-[80%] flex flex-col ${isOwnMessage ? 'items-end' : 'items-start'}`}>
                    {/* Username and time */}
                    <div className={`flex items-center gap-2 mb-1 px-1 ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'}`}>
                      <button
                        onClick={() => setSelectedUserProfile({ 
                          walletId: msg.walletId, 
                          username: msg.walletId === walletId ? username : (userProfiles[msg.walletId]?.username || msg.username)
                        })}
                        className="text-xs text-purple-400 hover:text-purple-300 transition-colors cursor-pointer"
                      >
                        {msg.walletId === walletId ? username : (userProfiles[msg.walletId]?.username || msg.username)}
                      </button>
                      <span className="text-[10px] text-slate-500">
                        {formatTime(msg.timestamp)}
                      </span>
                    </div>

                    {/* Reply indicator */}
                    {replyMsg && (
                      <div className={`mb-1.5 px-3 py-1.5 text-xs rounded-lg bg-slate-800/50 border-l-2 border-purple-500/50 max-w-full ${isOwnMessage ? 'self-end' : 'self-start'}`}>
                        <div className="flex items-center gap-1 text-slate-400 mb-0.5">
                          <Reply className="w-2.5 h-2.5 flex-shrink-0" />
                          <span className="text-purple-400 truncate">
                            {replyMsg.walletId === walletId ? username : (userProfiles[replyMsg.walletId]?.username || replyMsg.username)}
                          </span>
                        </div>
                        <p className="text-slate-300 truncate text-[11px]">{replyMsg.message}</p>
                      </div>
                    )}
                    
                    {/* Message bubble */}
                    <div className="relative">
                      <div
                        onTouchStart={(e) => handleMessageTouchStart(e, msg.id)}
                        onTouchMove={handleMessageTouchMove}
                        onTouchEnd={handleMessageTouchEnd}
                        className={`px-4 py-2.5 rounded-2xl shadow-lg select-none ${
                          isOwnMessage
                            ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-white shadow-purple-500/20 rounded-tr-sm'
                            : 'bg-gradient-to-br from-slate-800 to-slate-700 text-white shadow-black/20 rounded-tl-sm'
                        } ${touchStart?.messageId === msg.id ? 'scale-[0.98]' : ''} transition-transform`}
                        style={{ 
                          userSelect: 'none',
                          WebkitUserSelect: 'none',
                          WebkitTouchCallout: 'none'
                        }}
                      >
                        <p className="break-words leading-relaxed whitespace-pre-wrap text-[15px]">
                          {msg.message}
                        </p>
                      </div>

                      {/* Reaction picker */}
                      <AnimatePresence>
                        {showReactions === msg.id && canSendMessage() && (
                          <motion.div
                            key={`picker-${msg.id}`}
                            initial={{ opacity: 0, scale: 0.5, y: 10 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.5, y: 10 }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            className={`absolute ${isOwnMessage ? 'right-0' : 'left-0'} bottom-full mb-2 px-2 py-2 bg-slate-800/98 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-600/50 flex gap-1 z-50`}
                            style={{ 
                              pointerEvents: 'auto',
                              touchAction: 'none'
                            }}
                          >
                            {QUICK_REACTIONS.map((emoji, emojiIndex) => (
                              <motion.button
                                key={emoji}
                                type="button"
                                initial={{ scale: 0, rotate: -180 }}
                                animate={{ scale: 1, rotate: 0 }}
                                transition={{ 
                                  delay: emojiIndex * 0.03,
                                  type: "spring",
                                  stiffness: 500,
                                  damping: 25
                                }}
                                onTouchEnd={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  handleReaction(msg.id, emoji);
                                }}
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  handleReaction(msg.id, emoji);
                                }}
                                className="w-12 h-12 text-2xl flex items-center justify-center active:scale-95 rounded-xl transition-all hover:bg-slate-700/50"
                                style={{ 
                                  userSelect: 'none',
                                  WebkitTapHighlightColor: 'transparent'
                                }}
                              >
                                {emoji}
                              </motion.button>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Reactions display */}
                      {hasReactions && (
                        <div className={`flex flex-wrap gap-1 mt-1.5 ${isOwnMessage ? 'justify-end' : 'justify-start'}`}>
                          {Object.entries(msg.reactions || {}).map(([emoji, walletIds]) => {
                            const hasReacted = walletIds.includes(walletId);
                            return (
                              <motion.button
                                key={emoji}
                                type="button"
                                onClick={() => canSendMessage() && handleReaction(msg.id, emoji)}
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                exit={{ scale: 0 }}
                                whileTap={{ scale: 0.9 }}
                                className={`px-2 py-0.5 rounded-full text-sm flex items-center gap-1 transition-all ${
                                  hasReacted
                                    ? 'bg-purple-500/40 border-2 border-purple-400 shadow-lg shadow-purple-500/20'
                                    : 'bg-slate-700/60 border border-slate-600/80 active:bg-slate-600/70'
                                }`}
                              >
                                <span className="text-base leading-none">{emoji}</span>
                                {walletIds.length > 1 && (
                                  <span className={`text-[11px] leading-none ${hasReacted ? 'text-purple-200' : 'text-slate-300'}`}>
                                    {walletIds.length}
                                  </span>
                                )}
                              </motion.button>
                            );
                          })}
                        </div>
                      )}

                      {/* Reply button */}
                      {canSendMessage() && !isOptimistic && (
                        <button
                          type="button"
                          onClick={() => setReplyingTo(msg)}
                          className={`mt-1.5 text-[11px] text-purple-400 active:text-purple-300 transition-colors flex items-center gap-1 ${isOwnMessage ? 'ml-auto' : 'mr-auto'}`}
                        >
                          <Reply className="w-3 h-3" />
                          Reply
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply indicator */}
      <AnimatePresence>
        {replyingTo && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="px-4 py-2.5 border-t border-slate-800/50 bg-slate-900/80 backdrop-blur-sm"
          >
            <div className="flex items-start gap-2">
              <div className="p-1.5 bg-purple-500/10 rounded-lg">
                <Reply className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-purple-400 mb-0.5">
                  Replying to {replyingTo.username}
                </div>
                <p className="text-sm text-slate-300 truncate">{replyingTo.message}</p>
              </div>
              <button
                onClick={() => setReplyingTo(null)}
                className="p-1.5 hover:bg-slate-800 rounded-lg transition-colors flex-shrink-0 active:scale-95"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <div className="px-4 py-3 border-t border-slate-800/50 bg-gradient-to-br from-slate-900/95 to-black/95 backdrop-blur-xl">
        {canSendMessage() ? (
          <div className="flex items-end gap-2">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={replyingTo ? 'Write a reply...' : t.chat.typeMessage}
                className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700/50 rounded-2xl focus:outline-none focus:border-purple-500/50 focus:bg-slate-900 transition-all placeholder:text-slate-600 resize-none text-[16px]"
                disabled={sending}
                rows={1}
                style={{ 
                  minHeight: '48px',
                  maxHeight: '120px',
                  fontSize: '16px' // Prevents iOS zoom
                }}
              />
            </div>
            <motion.button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || sending}
              className="p-3.5 bg-gradient-to-r from-purple-600 to-purple-500 rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed disabled:from-slate-700 disabled:to-slate-600 shadow-lg shadow-purple-500/20 flex-shrink-0 active:scale-95 transition-transform"
              whileTap={{ scale: newMessage.trim() ? 0.9 : 1 }}
            >
              <Send className="w-5 h-5" />
            </motion.button>
          </div>
        ) : (
          <motion.div 
            className="p-4 bg-gradient-to-br from-red-500/10 via-orange-500/10 to-red-500/10 border border-red-500/20 rounded-2xl text-center relative overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-center gap-2 text-red-400 mb-1">
              <Lock className="w-4 h-4" />
              <span>{t.chat.tokenRequired}</span>
            </div>
            <p className="text-sm text-slate-400">
              {t.chat.youDontOwn} {selectedToken.symbol} tokens
            </p>
          </motion.div>
        )}
      </div>

      {/* User Profile Card */}
      <AnimatePresence>
        {selectedUserProfile && (
          <UserProfileCard
            walletId={selectedUserProfile.walletId}
            username={selectedUserProfile.username}
            onClose={() => setSelectedUserProfile(null)}
            isOwnProfile={selectedUserProfile.walletId === walletId}
            tokenBalance={selectedToken?.amount}
            tokenSymbol={selectedToken?.symbol}
          />
        )}
      </AnimatePresence>
    </div>
  );
}