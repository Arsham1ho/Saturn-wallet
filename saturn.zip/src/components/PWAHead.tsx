/**
 * PWA Head - Meta tags and manifest for Progressive Web App
 * This component should be included in the document head
 */

export function PWAHead() {
  return (
    <>
      {/* PWA Manifest */}
      <link rel="manifest" href="/manifest.json" />
      
      {/* Theme Color */}
      <meta name="theme-color" content="#9333EA" />
      <meta name="msapplication-TileColor" content="#9333EA" />
      
      {/* Apple Touch Icons */}
      <link rel="apple-touch-icon" sizes="180x180" href="/icons/icon-192x192.png" />
      <link rel="apple-touch-icon" sizes="152x152" href="/icons/icon-152x152.png" />
      <link rel="apple-touch-icon" sizes="120x120" href="/icons/icon-128x128.png" />
      
      {/* Favicon */}
      <link rel="icon" type="image/png" sizes="512x512" href="/icons/icon-512x512.png" />
      <link rel="icon" type="image/png" sizes="192x192" href="/icons/icon-192x192.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/icons/icon-128x128.png" />
      
      {/* iOS Meta Tags */}
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <meta name="apple-mobile-web-app-title" content="Saturn Wallet" />
      
      {/* Mobile Viewport */}
      <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=no" />
      
      {/* App Description */}
      <meta name="description" content="Saturn Wallet - Your Web3 Solana Wallet. Fast, Secure, Beautiful." />
      <meta name="keywords" content="crypto, wallet, solana, web3, defi, nft" />
      
      {/* Open Graph */}
      <meta property="og:title" content="Saturn Wallet" />
      <meta property="og:description" content="Your Web3 Solana Wallet - Fast, Secure, Beautiful" />
      <meta property="og:type" content="website" />
      <meta property="og:image" content="/icons/icon-512x512.png" />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content="Saturn Wallet" />
      <meta name="twitter:description" content="Your Web3 Solana Wallet - Fast, Secure, Beautiful" />
      <meta name="twitter:image" content="/icons/icon-512x512.png" />
    </>
  );
}
