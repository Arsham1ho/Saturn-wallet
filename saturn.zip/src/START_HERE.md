# 🪐 Saturn Wallet - شروع کنید اینجا!

خوش آمدید! این راهنمای سریع شروع به کار است.

---

## 📚 فایل‌های مهم

### برای شروع سریع:
1. **[README.md](./README.md)** - مستندات کامل اپلیکیشن
2. **[DEPLOYMENT.md](./DEPLOYMENT.md)** - راهنمای استقرار
3. **[READY_TO_LAUNCH_FA.md](./READY_TO_LAUNCH_FA.md)** - راهنمای فارسی راه‌اندازی

### برای تست و Launch:
4. **[LAUNCH_CHECKLIST.md](./LAUNCH_CHECKLIST.md)** - چک‌لیست کامل قبل از راه‌اندازی
5. **[PRODUCTION_READY.md](./PRODUCTION_READY.md)** - تأیید آمادگی برای production

---

## 🚀 شروع سریع (5 دقیقه)

### مرحله 1: نصب
```bash
npm install
```

### مرحله 2: تنظیم API Keys
در Figma Make، به Settings → Secrets برید و این متغیرها رو اضافه کنید:

```
HELIUS_API_KEY=your_helius_api_key
ALCHEMY_API_KEY=your_alchemy_api_key
```

**کجا بگیرم؟**
- Helius: [helius.dev](https://helius.dev) - برای Solana
- Alchemy: [alchemy.com](https://alchemy.com) - برای Ethereum

### مرحله 3: اجرا
```bash
npm run dev
```

اپلیکیشن در `http://localhost:3000` اجرا می‌شه!

---

## ✅ چک کنید که کار می‌کنه

1. **صفحه Landing** - باید انیمیشن welcome رو ببینید
2. **Create Wallet** - یک کیف پول جدید بسازید
3. **Recovery Phrase** - 12 کلمه رو ببینید و یادداشت کنید
4. **Home Page** - موجودی SOL, ETH, BTC رو ببینید
5. **Swap** - تبدیل SOL به USDC رو تست کنید

---

## 🎯 آماده برای انتشار؟

### قبل از Deploy:

1. **API Keys رو تنظیم کنید** (فوق‌العاده مهم!)
   - ✅ HELIUS_API_KEY
   - ✅ ALCHEMY_API_KEY
   - ✅ SUPABASE keys (خودکار تنظیم می‌شه)

2. **چک‌لیست رو بررسی کنید**
   ```bash
   # فایل LAUNCH_CHECKLIST.md رو باز کنید
   ```

3. **یک بار دیگه تست کنید**
   - ساخت wallet
   - Import wallet
   - ارسال تراکنش کوچک
   - Swap توکن‌ها

### Deploy:

#### گزینه 1: Vercel (آسان‌ترین)
1. کد رو به GitHub push کنید
2. به [vercel.com](https://vercel.com) برید
3. Repository رو import کنید
4. API keys رو اضافه کنید
5. Deploy!

#### گزینه 2: Netlify
1. به [netlify.com](https://netlify.com) برید
2. Repository رو connect کنید
3. API keys رو اضافه کنید
4. Deploy!

**راهنمای کامل:** [DEPLOYMENT.md](./DEPLOYMENT.md)

---

## 📖 ساختار پروژه

```
saturn-wallet/
├── components/           # React components
│   ├── pages/           # صفحات اصلی (Home, Swap, etc)
│   ├── ui/              # UI components (shadcn)
│   └── ...
├── utils/               # ابزارها و helpers
│   ├── wallet.ts        # مدیریت کیف پول
│   ├── blockchain.ts    # ارتباط با blockchain
│   └── ...
├── public/              # فایل‌های استاتیک
│   ├── manifest.json    # PWA manifest
│   └── sw.js           # Service worker
└── supabase/            # Backend (Edge Functions)
```

---

## 🔑 ویژگی‌های کلیدی

### 🔐 امنیت
- رمزنگاری client-side با AES-256-GCM
- Private keys هیچوقت از دستگاه خارج نمی‌شن
- عبارت بازیابی BIP39 استاندارد
- Biometric authentication (Face ID/Touch ID)

### 🌐 Multi-Chain
- Solana (SOL + SPL tokens)
- Ethereum (ETH + ERC20)
- Bitcoin (BTC)
- Base, Polygon, Sui

### 💸 DeFi
- Send tokens
- Swap via Jupiter
- Real-time prices
- Transaction history

### 🎨 UX
- Phantom-inspired design
- PWA installable
- Dark mode
- Multi-language
- Responsive

---

## 🆘 کمک نیاز دارید؟

### مستندات
- **عمومی**: [README.md](./README.md)
- **Deploy**: [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Launch**: [LAUNCH_CHECKLIST.md](./LAUNCH_CHECKLIST.md)
- **فارسی**: [READY_TO_LAUNCH_FA.md](./READY_TO_LAUNCH_FA.md)
- **Troubleshooting**: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) ← **مشکل دارید؟ اینجا ببینید!**

### مشکلات رایج

**API Keys کار نمی‌کنه؟**
- مطمئن شید که در Secrets تنظیم شدن
- نام‌ها دقیقاً مطابق باشن (case-sensitive)
- بعد از اضافه کردن، app رو restart کنید
- راهنمای کامل: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

**موجودی‌ها نمایش داده نمی‌شن؟**
- API keys رو چک کنید
- Console رو برای errors بررسی کنید
- اگه API key ندارید، demo data نمایش داده می‌شه (این طبیعیه!)
- راهنمای کامل: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

**Transaction fail می‌شه؟**
- موجودی کافی داشته باشید
- آدرس مقصد رو بررسی کنید
- با مقدار کوچک تست کنید
- راهنمای کامل: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

**خطای "upstream c... is not valid JSON"؟**
- این خطا از Alchemy API میاد
- یا API key نامعتبره یا تنظیم نشده
- اپ خودکار به demo data می‌ره
- برای رفع: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md#1-error-fetching-ethereum-balance-upstream-c-is-not-valid-json)

---

## 🎯 مرحله بعدی

1. ✅ اپلیکیشن رو اجرا کنید
2. ✅ یک کیف پول بسازید
3. ✅ ویژگی‌ها رو تست کنید
4. ✅ API keys رو تنظیم کنید
5. ✅ Deploy کنید!

---

## 📞 پشتیبانی

- **Issues**: GitHub Issues
- **Documentation**: فایل‌های MD در root
- **Community**: Discord/Telegram (coming soon)

---

<div align="center">

## 🎉 آماده شروع!

همه چیز آماده است. فقط API keys رو تنظیم کنید و شروع کنید!

**موفق باشید! 🚀**

[شروع Development](#-شروع-سریع-5-دقیقه) • [آماده Deploy؟](#-آماده-برای-انتشار) • [کمک](#-کمک-نیاز-دارید)

</div>