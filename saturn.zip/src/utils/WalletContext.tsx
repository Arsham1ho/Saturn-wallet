import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SecureStorage, WalletStorage, deriveAddresses } from './wallet';
import type { DerivedAccount } from './wallet';
import { useNetwork } from './NetworkContext';

interface WalletContextType {
  mnemonic: string | null;
  walletId: string | null;
  addresses: {
    solana: string;
    ethereum: string;
    base: string;
    polygon: string;
    bitcoin: string;
    sui: string;
  } | null;
  currentAccount: number;
  isUnlocked: boolean;
  unlock: (password: string) => Promise<boolean>;
  lock: () => void;
  switchAccount: (accountIndex: number) => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ 
  children, 
  walletId 
}: { 
  children: ReactNode;
  walletId?: string;
}) {
  const [mnemonic, setMnemonic] = useState<string | null>(null);
  const [addresses, setAddresses] = useState<WalletContextType['addresses']>(null);
  const [currentAccount, setCurrentAccount] = useState(0);
  const [isUnlocked, setIsUnlocked] = useState(false);

  useEffect(() => {
    // Load current account from storage
    const savedAccount = WalletStorage.getCurrentAccount();
    setCurrentAccount(savedAccount);
  }, []);

  const unlock = async (password: string): Promise<boolean> => {
    try {
      const decryptedMnemonic = await SecureStorage.retrieveMnemonic(password);
      
      if (!decryptedMnemonic) {
        console.error('[WalletContext] Failed to decrypt mnemonic');
        return false;
      }

      console.log('[WalletContext] ✅ Mnemonic decrypted successfully');
      setMnemonic(decryptedMnemonic);
      setIsUnlocked(true);

      // Derive addresses
      const derivedAddresses = await deriveAddresses(decryptedMnemonic, currentAccount);
      setAddresses(derivedAddresses);
      
      console.log('[WalletContext] 🔑 Addresses derived:', {
        solana: derivedAddresses.solana,
        ethereum: derivedAddresses.ethereum,
      });

      // Store addresses in server KV store for blockchain check endpoint
      if (walletId) {
        try {
          const { projectId, publicAnonKey } = await import('../utils/supabase/info');
          await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-e5bc10d1/store-addresses`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${publicAnonKey}`,
              },
              body: JSON.stringify({
                walletId,
                addresses: derivedAddresses,
              }),
            }
          );
          console.log('[WalletContext] 📡 Addresses synced to server');
        } catch (error) {
          console.warn('[WalletContext] Failed to sync addresses to server:', error);
          // Non-critical error, continue anyway
        }
      }

      return true;
    } catch (error) {
      console.error('[WalletContext] Error unlocking wallet:', error);
      return false;
    }
  };

  const lock = () => {
    setMnemonic(null);
    setIsUnlocked(false);
    setAddresses(null);
    console.log('[WalletContext] 🔒 Wallet locked');
  };

  const switchAccount = async (accountIndex: number) => {
    if (!mnemonic) {
      console.error('[WalletContext] Cannot switch account - wallet is locked');
      return;
    }

    setCurrentAccount(accountIndex);
    WalletStorage.setCurrentAccount(accountIndex);

    // Re-derive addresses for new account
    const derivedAddresses = await deriveAddresses(mnemonic, accountIndex);
    setAddresses(derivedAddresses);

    console.log('[WalletContext] 🔄 Switched to account', accountIndex);
  };

  return (
    <WalletContext.Provider
      value={{
        mnemonic,
        walletId,
        addresses,
        currentAccount,
        isUnlocked,
        unlock,
        lock,
        switchAccount,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}