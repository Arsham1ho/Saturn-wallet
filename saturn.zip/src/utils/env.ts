/**
 * Environment Variables Configuration
 * 
 * Saturn Wallet reads API keys directly from environment variables (CLIENT-SIDE)
 */

/**
 * Get Helius API key from environment
 */
export function getHeliusApiKey(): string | undefined {
  // Check if running in browser
  if (typeof window === 'undefined') return undefined;
  
  // Try to get from window.ENV (set by server)
  const key = (window as any).ENV?.HELIUS_API_KEY;
  
  if (!key) {
    console.warn('[ENV] ⚠️ HELIUS_API_KEY not found. Add it to your environment variables.');
  }
  
  return key;
}

/**
 * Get Alchemy API key from environment
 */
export function getAlchemyApiKey(): string | undefined {
  // Check if running in browser
  if (typeof window === 'undefined') return undefined;
  
  // Try to get from window.ENV (set by server)
  const key = (window as any).ENV?.ALCHEMY_API_KEY;
  
  if (!key) {
    console.warn('[ENV] ⚠️ ALCHEMY_API_KEY not found. Add it to your environment variables.');
  }
  
  return key;
}

// Helper to check if APIs are configured
export function areApiKeysConfigured(): {
  helius: boolean;
  alchemy: boolean;
  allConfigured: boolean;
} {
  const helius = !!getHeliusApiKey();
  const alchemy = !!getAlchemyApiKey();
  
  return {
    helius,
    alchemy,
    allConfigured: helius && alchemy
  };
}