import React, { createContext, useContext, useState, useEffect } from 'react';

/**
 * Network Context - Manages Testnet/Mainnet Mode (Like Phantom)
 * 
 * When testnet is enabled:
 * - Solana: Connects to Devnet
 * - Ethereum: Connects to Sepolia
 * - Bitcoin: Connects to Testnet
 */

export type NetworkMode = 'mainnet' | 'testnet';

interface NetworkContextType {
  networkMode: NetworkMode;
  isTestnet: boolean;
  toggleNetwork: () => void;
  setNetworkMode: (mode: NetworkMode) => void;
}

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export function NetworkProvider({ children }: { children: React.ReactNode }) {
  const [networkMode, setNetworkModeState] = useState<NetworkMode>('mainnet');

  // Load network mode from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('saturn_network_mode');
    if (saved === 'testnet' || saved === 'mainnet') {
      setNetworkModeState(saved);
      console.log('[Network] 🌐 Loaded network mode:', saved);
    }
  }, []);

  // Save network mode to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('saturn_network_mode', networkMode);
    console.log('[Network] 💾 Network mode changed to:', networkMode);
  }, [networkMode]);

  const toggleNetwork = () => {
    setNetworkModeState(prev => prev === 'mainnet' ? 'testnet' : 'mainnet');
  };

  const setNetworkMode = (mode: NetworkMode) => {
    setNetworkModeState(mode);
  };

  const value: NetworkContextType = {
    networkMode,
    isTestnet: networkMode === 'testnet',
    toggleNetwork,
    setNetworkMode,
  };

  return (
    <NetworkContext.Provider value={value}>
      {children}
    </NetworkContext.Provider>
  );
}

export function useNetwork() {
  const context = useContext(NetworkContext);
  if (context === undefined) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
}

/**
 * Get RPC endpoints based on network mode
 */
export function getNetworkEndpoints(networkMode: NetworkMode) {
  if (networkMode === 'testnet') {
    return {
      solana: {
        name: 'Solana Devnet',
        rpc: 'https://api.devnet.solana.com',
        explorer: 'https://explorer.solana.com',
        explorerParam: 'devnet',
      },
      ethereum: {
        name: 'Sepolia Testnet',
        rpc: 'https://eth-sepolia.g.alchemy.com/v2/',
        chainId: 11155111,
        explorer: 'https://sepolia.etherscan.io',
      },
      bitcoin: {
        name: 'Bitcoin Testnet',
        explorer: 'https://blockstream.info/testnet',
      },
      polygon: {
        name: 'Polygon Mumbai',
        rpc: 'https://polygon-mumbai.g.alchemy.com/v2/',
        chainId: 80001,
        explorer: 'https://mumbai.polygonscan.com',
      },
      base: {
        name: 'Base Sepolia',
        rpc: 'https://base-sepolia.g.alchemy.com/v2/',
        chainId: 84532,
        explorer: 'https://sepolia.basescan.org',
      },
    };
  }

  // Mainnet
  return {
    solana: {
      name: 'Solana Mainnet',
      rpc: 'https://api.mainnet-beta.solana.com',
      explorer: 'https://explorer.solana.com',
      explorerParam: '',
    },
    ethereum: {
      name: 'Ethereum Mainnet',
      rpc: 'https://eth-mainnet.g.alchemy.com/v2/',
      chainId: 1,
      explorer: 'https://etherscan.io',
    },
    bitcoin: {
      name: 'Bitcoin Mainnet',
      explorer: 'https://blockstream.info',
    },
    polygon: {
      name: 'Polygon Mainnet',
      rpc: 'https://polygon-mainnet.g.alchemy.com/v2/',
      chainId: 137,
      explorer: 'https://polygonscan.com',
    },
    base: {
      name: 'Base Mainnet',
      rpc: 'https://base-mainnet.g.alchemy.com/v2/',
      chainId: 8453,
      explorer: 'https://basescan.org',
    },
  };
}
