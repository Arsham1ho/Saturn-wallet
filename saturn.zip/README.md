
  # Crypto Currency Wallet App

  This is a code bundle for Crypto Currency Wallet App. The original project is available at https://www.figma.com/design/yVL8T7TPvAN414IhviI6J5/Crypto-Currency-Wallet-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  